import React from 'react'

export default function Error() {
  return (
    <div>
      <h1 style={{textAlign:'center',marginTop:'100px'}}>Error 404 found </h1>
    </div>
  )
}
